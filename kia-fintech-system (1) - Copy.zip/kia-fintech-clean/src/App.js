// ============================================================
// App.js  -  The main component that holds everything together
// ============================================================
// This is the "root" of the application.
// It decides WHICH page to show based on the 'activePage' state.
// Think of it like a controller that switches between screens.

import { useState } from "react";
import "./styles.css";

// Import the Sidebar navigation
import Sidebar from "./components/Sidebar";

// Import all the pages
import Dashboard from "./pages/Dashboard";
import Customers from "./pages/Customers";
import Cars      from "./pages/Cars";
import Services  from "./pages/Services";
import Payments  from "./pages/Payments";
import Cashbacks from "./pages/Cashbacks";

function App() {

  // activePage keeps track of which section the user is on
  // Default: "dashboard" (first page shown when app loads)
  const [activePage, setActivePage] = useState("dashboard");

  // This function decides which page component to render
  // based on the value of activePage
  function renderPage() {
    if (activePage === "dashboard") return <Dashboard />;
    if (activePage === "customers") return <Customers />;
    if (activePage === "cars")      return <Cars />;
    if (activePage === "services")  return <Services />;
    if (activePage === "payments")  return <Payments />;
    if (activePage === "cashbacks") return <Cashbacks />;
    return <Dashboard />;  // fallback
  }

  return (
    // The outer wrapper holds sidebar + main content side by side
    <div className="app-wrapper">

      {/* LEFT: Sidebar navigation */}
      <Sidebar activePage={activePage} setPage={setActivePage} />

      {/* RIGHT: Page content */}
      <main className="main-content">
        {renderPage()}
      </main>

    </div>
  );
}

export default App;
