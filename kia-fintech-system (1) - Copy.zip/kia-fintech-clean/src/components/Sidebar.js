// ============================================================
// Sidebar.js  -  Left navigation panel
// ============================================================
// Props it receives:
//   activePage  - which page is currently shown (string)
//   setPage     - function to change the page

function Sidebar({ activePage, setPage }) {

  // All the nav links in an array
  // icon = emoji, label = display name, page = the key we use in state
  const navItems = [
    { icon: "📊", label: "Dashboard",  page: "dashboard"  },
    { icon: "👥", label: "Customers",  page: "customers"  },
    { icon: "🚗", label: "Cars",       page: "cars"       },
    { icon: "🔧", label: "Services",   page: "services"   },
    { icon: "💳", label: "Payments",   page: "payments"   },
    { icon: "🎁", label: "Cashbacks",  page: "cashbacks"  },
  ];

  return (
    <aside className="sidebar">

      {/* Logo section at the top */}
      <div className="sidebar-logo">
        <h2><span>KIA</span> FinTech</h2>
        <p>Garage Management System</p>
      </div>

      {/* Navigation links */}
      <nav className="sidebar-nav">
        <p className="sidebar-section-label">Main Menu</p>
        <ul>
          {navItems.map((item) => (
            <li key={item.page}>
              <button
                onClick={() => setPage(item.page)}
                className={activePage === item.page ? "active" : ""}
              >
                <span className="nav-icon">{item.icon}</span>
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      {/* Bottom info */}
      <div style={{ padding: "16px 20px", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <p style={{ fontSize: "11px", color: "rgba(255,255,255,0.3)", textAlign: "center" }}>
          KIA Motors Garage v1.0
        </p>
      </div>
    </aside>
  );
}

export default Sidebar;
