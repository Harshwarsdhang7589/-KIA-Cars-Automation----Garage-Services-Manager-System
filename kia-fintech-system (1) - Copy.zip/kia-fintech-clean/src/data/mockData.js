// ============================================================
// mockData.js  -  This file acts like our database
// ============================================================
// In a real project this data would come from a backend server
// (Node.js + MySQL). For now we store it here as JavaScript
// objects so the React app can work without a server.
// ============================================================

export const customers = [
  {
    customer_id: 1,
    full_name: "Ravi Sharma",
    email: "ravi@email.com",
    phone: "9876543210",
    address: "Mumbai, Maharashtra",
    joined_date: "2024-01-15",
    loyalty_points: 120,
  },
  {
    customer_id: 2,
    full_name: "Priya Mehta",
    email: "priya@email.com",
    phone: "9123456789",
    address: "Pune, Maharashtra",
    joined_date: "2024-03-20",
    loyalty_points: 80,
  },
  {
    customer_id: 3,
    full_name: "Arjun Singh",
    email: "arjun@email.com",
    phone: "9012345678",
    address: "Delhi, NCR",
    joined_date: "2023-11-10",
    loyalty_points: 200,
  },
  {
    customer_id: 4,
    full_name: "Sneha Patil",
    email: "sneha@email.com",
    phone: "9654321087",
    address: "Nagpur, Maharashtra",
    joined_date: "2024-05-01",
    loyalty_points: 50,
  },
];

export const cars = [
  {
    car_id: 1,
    customer_id: 1,
    model: "KIA Seltos",
    variant: "HTX+",
    color: "Steel Silver",
    reg_number: "MH12-AB-1234",
    purchase_date: "2024-01-15",
  },
  {
    car_id: 2,
    customer_id: 2,
    model: "KIA Sonet",
    variant: "GTX",
    color: "Gravity Grey",
    reg_number: "MH14-CD-5678",
    purchase_date: "2024-03-20",
  },
  {
    car_id: 3,
    customer_id: 3,
    model: "KIA Carens",
    variant: "Prestige+",
    color: "Aurora Black Pearl",
    reg_number: "DL01-EF-9012",
    purchase_date: "2023-11-10",
  },
  {
    car_id: 4,
    customer_id: 4,
    model: "KIA EV6",
    variant: "GT Line",
    color: "Snow White",
    reg_number: "MH31-GH-3456",
    purchase_date: "2024-05-01",
  },
];

export const services = [
  {
    service_id: 1,
    car_id: 1,
    service_type: "Oil Change",
    description: "Engine oil replaced - 5W30 synthetic",
    service_date: "2024-06-10",
    cost: 1800,
    status: "Completed",
    mechanic_name: "Manoj Kumar",
  },
  {
    service_id: 2,
    car_id: 2,
    service_type: "AC Service",
    description: "AC gas refill and filter cleaning",
    service_date: "2024-06-12",
    cost: 2500,
    status: "Completed",
    mechanic_name: "Deepak Rao",
  },
  {
    service_id: 3,
    car_id: 3,
    service_type: "Wheel Alignment",
    description: "Four wheel alignment + balancing",
    service_date: "2024-06-15",
    cost: 1200,
    status: "In Progress",
    mechanic_name: "Suresh Nair",
  },
  {
    service_id: 4,
    car_id: 4,
    service_type: "Annual Service",
    description: "Full vehicle checkup and service",
    service_date: "2024-06-18",
    cost: 5500,
    status: "Pending",
    mechanic_name: "Ramesh Joshi",
  },
];

export const payments = [
  {
    payment_id: 1,
    customer_id: 1,
    service_id: 1,
    amount: 1800,
    payment_method: "UPI",
    payment_date: "2024-06-10",
    status: "Paid",
    invoice_number: "INV-2024-001",
  },
  {
    payment_id: 2,
    customer_id: 2,
    service_id: 2,
    amount: 2500,
    payment_method: "Card",
    payment_date: "2024-06-12",
    status: "Paid",
    invoice_number: "INV-2024-002",
  },
  {
    payment_id: 3,
    customer_id: 3,
    service_id: 3,
    amount: 1200,
    payment_method: "Cash",
    payment_date: "2024-06-15",
    status: "Pending",
    invoice_number: "INV-2024-003",
  },
  {
    payment_id: 4,
    customer_id: 4,
    service_id: 4,
    amount: 5500,
    payment_method: "UPI",
    payment_date: "2024-06-18",
    status: "Pending",
    invoice_number: "INV-2024-004",
  },
];

export const cashbacks = [
  {
    cashback_id: 1,
    customer_id: 1,
    payment_id: 1,
    cashback_amount: 180,
    reason: "Loyal Customer 10% Back",
    applied_date: "2024-06-10",
    is_redeemed: true,
  },
  {
    cashback_id: 2,
    customer_id: 2,
    payment_id: 2,
    cashback_amount: 250,
    reason: "Weekend Special Offer",
    applied_date: "2024-06-12",
    is_redeemed: false,
  },
  {
    cashback_id: 3,
    customer_id: 3,
    payment_id: 3,
    cashback_amount: 60,
    reason: "First Time Service Discount",
    applied_date: "2024-06-15",
    is_redeemed: false,
  },
];
