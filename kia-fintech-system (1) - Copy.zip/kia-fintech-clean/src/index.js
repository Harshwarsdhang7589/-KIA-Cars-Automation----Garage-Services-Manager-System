// ============================================================
// index.js  -  React's starting point
// ============================================================
// This file is the very first thing React runs.
// It finds the <div id="root"> in public/index.html
// and mounts the entire App component inside it.

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

// Find the root div in index.html and render App inside it
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
