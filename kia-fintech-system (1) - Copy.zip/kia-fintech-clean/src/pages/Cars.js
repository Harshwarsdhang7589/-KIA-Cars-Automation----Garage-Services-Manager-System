// ============================================================
// Cars.js  -  All KIA cars registered in the garage
// ============================================================
// Features:
//   - View all cars with their owner's name
//   - Add a new car (linked to an existing customer)

import { useState } from "react";
import { cars as initialCars, customers } from "../data/mockData";

function Cars() {
  const [list, setList] = useState(initialCars);
  const [showModal, setShowModal] = useState(false);

  // KIA models that this garage handles
  const kiaModels = ["KIA Seltos", "KIA Sonet", "KIA Carens", "KIA EV6", "KIA Carnival"];

  const [newCar, setNewCar] = useState({
    customer_id: "",
    model: "",
    variant: "",
    color: "",
    reg_number: "",
    purchase_date: "",
  });

  function handleChange(e) {
    setNewCar({ ...newCar, [e.target.name]: e.target.value });
  }

  function handleAdd() {
    if (!newCar.customer_id || !newCar.model || !newCar.reg_number) {
      alert("Please fill Customer, Model and Registration Number");
      return;
    }

    const carToAdd = {
      car_id: list.length + 1,
      ...newCar,
      customer_id: parseInt(newCar.customer_id), // convert to number
    };

    setList([...list, carToAdd]);
    setNewCar({ customer_id: "", model: "", variant: "", color: "", reg_number: "", purchase_date: "" });
    setShowModal(false);
  }

  // Get customer name by id (to show in the table)
  function getOwnerName(customerId) {
    const c = customers.find((cust) => cust.customer_id === customerId);
    return c ? c.full_name : "Unknown";
  }

  return (
    <div>
      <div className="page-header">
        <h1>Cars</h1>
        <p>All KIA vehicles registered in the garage system</p>
      </div>

      <div className="card">
        <div className="card-header">
          <h3>Registered Vehicles ({list.length})</h3>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            + Register Car
          </button>
        </div>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Owner</th>
                <th>Model</th>
                <th>Variant</th>
                <th>Color</th>
                <th>Reg. Number</th>
                <th>Purchase Date</th>
              </tr>
            </thead>
            <tbody>
              {list.map((car) => (
                <tr key={car.car_id}>
                  <td className="text-muted">{car.car_id}</td>
                  <td className="text-bold">{getOwnerName(car.customer_id)}</td>
                  <td>
                    <span className="badge badge-red">{car.model}</span>
                  </td>
                  <td>{car.variant}</td>
                  <td>{car.color}</td>
                  <td style={{ fontFamily: "monospace" }}>{car.reg_number}</td>
                  <td>{car.purchase_date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD CAR MODAL */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h2>Register New Car</h2>

            <div className="form-group">
              <label>Car Owner (Customer) *</label>
              <select name="customer_id" value={newCar.customer_id} onChange={handleChange}>
                <option value="">-- Select Customer --</option>
                {customers.map((c) => (
                  <option key={c.customer_id} value={c.customer_id}>
                    {c.full_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>KIA Model *</label>
                <select name="model" value={newCar.model} onChange={handleChange}>
                  <option value="">-- Select Model --</option>
                  {kiaModels.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>Variant</label>
                <input
                  type="text"
                  name="variant"
                  value={newCar.variant}
                  onChange={handleChange}
                  placeholder="e.g. HTX+, GTX"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Color</label>
                <input
                  type="text"
                  name="color"
                  value={newCar.color}
                  onChange={handleChange}
                  placeholder="e.g. Steel Silver"
                />
              </div>
              <div className="form-group">
                <label>Registration Number *</label>
                <input
                  type="text"
                  name="reg_number"
                  value={newCar.reg_number}
                  onChange={handleChange}
                  placeholder="e.g. MH12-XX-0000"
                />
              </div>
            </div>

            <div className="form-group">
              <label>Purchase Date</label>
              <input
                type="date"
                name="purchase_date"
                value={newCar.purchase_date}
                onChange={handleChange}
              />
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleAdd}>
                Register Car
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Cars;
