// ============================================================
// Cashbacks.js  -  Customer cashback and offers management
// ============================================================
// Features:
//   - View all cashback entries
//   - Mark cashback as redeemed
//   - Add a new cashback offer

import { useState } from "react";
import { cashbacks as initialCashbacks, customers, payments } from "../data/mockData";

function Cashbacks() {
  const [list, setList] = useState(initialCashbacks);
  const [showModal, setShowModal] = useState(false);

  const cashbackReasons = [
    "Loyal Customer 10% Back",
    "Weekend Special Offer",
    "First Time Service Discount",
    "Festival Offer",
    "Referral Bonus",
    "Anniversary Discount",
    "Free First Service",
  ];

  const [newCashback, setNewCashback] = useState({
    customer_id: "",
    payment_id: "",
    cashback_amount: "",
    reason: "",
    applied_date: "",
    is_redeemed: false,
  });

  function handleChange(e) {
    const value = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setNewCashback({ ...newCashback, [e.target.name]: value });
  }

  function handleAdd() {
    if (!newCashback.customer_id || !newCashback.cashback_amount || !newCashback.reason) {
      alert("Please fill Customer, Amount and Reason");
      return;
    }

    const toAdd = {
      cashback_id:     list.length + 1,
      customer_id:     parseInt(newCashback.customer_id),
      payment_id:      parseInt(newCashback.payment_id) || null,
      cashback_amount: parseFloat(newCashback.cashback_amount),
      reason:          newCashback.reason,
      applied_date:    newCashback.applied_date || new Date().toISOString().split("T")[0],
      is_redeemed:     newCashback.is_redeemed,
    };

    setList([...list, toAdd]);
    setNewCashback({ customer_id: "", payment_id: "", cashback_amount: "", reason: "", applied_date: "", is_redeemed: false });
    setShowModal(false);
  }

  // Redeem a cashback (mark is_redeemed = true)
  function redeemCashback(id) {
    setList(list.map((c) =>
      c.cashback_id === id ? { ...c, is_redeemed: true } : c
    ));
  }

  function getCustomerName(id) {
    const c = customers.find((c) => c.customer_id === id);
    return c ? c.full_name : "Unknown";
  }

  function getInvoice(paymentId) {
    if (!paymentId) return "—";
    const p = payments.find((p) => p.payment_id === paymentId);
    return p ? p.invoice_number : "—";
  }

  // Total unredeemed cashback
  const pendingCashback = list
    .filter((c) => !c.is_redeemed)
    .reduce((sum, c) => sum + c.cashback_amount, 0);

  return (
    <div>
      <div className="page-header">
        <h1>Cashbacks & Offers</h1>
        <p>Manage customer cashbacks, discounts and loyalty rewards</p>
      </div>

      {/* Summary */}
      <div className="stats-grid" style={{ marginBottom: "20px" }}>
        <div className="stat-card">
          <div className="stat-icon green">🎁</div>
          <div className="stat-info">
            <h3>₹{list.reduce((s, c) => s + c.cashback_amount, 0).toLocaleString()}</h3>
            <p>Total Cashback Issued</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">💸</div>
          <div className="stat-info">
            <h3>₹{pendingCashback.toLocaleString()}</h3>
            <p>Unredeemed Cashback</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">✅</div>
          <div className="stat-info">
            <h3>{list.filter((c) => c.is_redeemed).length}</h3>
            <p>Cashbacks Redeemed</p>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3>Cashback Records</h3>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            + Add Cashback
          </button>
        </div>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Customer</th>
                <th>Invoice</th>
                <th>Cashback</th>
                <th>Reason</th>
                <th>Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {list.map((cb) => (
                <tr key={cb.cashback_id}>
                  <td className="text-muted">{cb.cashback_id}</td>
                  <td className="text-bold">{getCustomerName(cb.customer_id)}</td>
                  <td style={{ fontFamily: "monospace", fontSize: "12px" }}>
                    {getInvoice(cb.payment_id)}
                  </td>
                  <td className="text-bold text-green">₹{cb.cashback_amount}</td>
                  <td>{cb.reason}</td>
                  <td>{cb.applied_date}</td>
                  <td>
                    <span className={cb.is_redeemed ? "badge badge-grey" : "badge badge-green"}>
                      {cb.is_redeemed ? "Redeemed" : "Available"}
                    </span>
                  </td>
                  <td>
                    {!cb.is_redeemed && (
                      <button
                        className="btn btn-outline"
                        style={{ padding: "4px 10px", fontSize: "12px" }}
                        onClick={() => redeemCashback(cb.cashback_id)}
                      >
                        Redeem
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD CASHBACK MODAL */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h2>Add Cashback / Offer</h2>

            <div className="form-row">
              <div className="form-group">
                <label>Customer *</label>
                <select name="customer_id" value={newCashback.customer_id} onChange={handleChange}>
                  <option value="">-- Select Customer --</option>
                  {customers.map((c) => (
                    <option key={c.customer_id} value={c.customer_id}>{c.full_name}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>Linked Invoice (optional)</label>
                <select name="payment_id" value={newCashback.payment_id} onChange={handleChange}>
                  <option value="">-- None --</option>
                  {payments.map((p) => (
                    <option key={p.payment_id} value={p.payment_id}>{p.invoice_number}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Cashback Amount (₹) *</label>
                <input
                  type="number"
                  name="cashback_amount"
                  value={newCashback.cashback_amount}
                  onChange={handleChange}
                  placeholder="e.g. 200"
                />
              </div>
              <div className="form-group">
                <label>Applied Date</label>
                <input type="date" name="applied_date" value={newCashback.applied_date} onChange={handleChange} />
              </div>
            </div>

            <div className="form-group">
              <label>Reason / Offer Name *</label>
              <select name="reason" value={newCashback.reason} onChange={handleChange}>
                <option value="">-- Select Reason --</option>
                {cashbackReasons.map((r) => <option key={r}>{r}</option>)}
              </select>
            </div>

            <div className="form-group" style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <input
                type="checkbox"
                name="is_redeemed"
                id="redeemed"
                checked={newCashback.is_redeemed}
                onChange={handleChange}
                style={{ width: "auto" }}
              />
              <label htmlFor="redeemed" style={{ marginBottom: 0, textTransform: "none", fontSize: "14px" }}>
                Already Redeemed
              </label>
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleAdd}>Save Cashback</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Cashbacks;
