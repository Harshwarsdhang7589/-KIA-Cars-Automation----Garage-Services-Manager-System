// ============================================================
// Customers.js  -  Manage all KIA customers
// ============================================================
// Features:
//   - Shows all customers in a table
//   - Search by name
//   - Add new customer via a modal popup form
//   - View customer's loyalty points

import { useState } from "react";
import { customers as initialData } from "../data/mockData";

function Customers() {

  // useState: React hook that lets us store and change data
  // 'list' starts with the data from our mockData file
  const [list, setList] = useState(initialData);

  // searchText: what the user types in the search box
  const [searchText, setSearchText] = useState("");

  // showModal: true = show the "Add Customer" popup, false = hide it
  const [showModal, setShowModal] = useState(false);

  // newCustomer: the form data for adding a new customer
  const [newCustomer, setNewCustomer] = useState({
    full_name: "",
    email: "",
    phone: "",
    address: "",
  });

  // --- Filter customers based on search text ---
  // We filter every time the component re-renders (when user types)
  const filtered = list.filter((c) =>
    c.full_name.toLowerCase().includes(searchText.toLowerCase())
  );

  // --- Handle typing in the form ---
  // 'e' is the event, e.target.name is the field name, e.target.value is what was typed
  function handleFormChange(e) {
    setNewCustomer({
      ...newCustomer,          // keep all existing fields
      [e.target.name]: e.target.value, // update only the field that changed
    });
  }

  // --- Add the new customer to the list ---
  function handleAddCustomer() {
    // Basic validation: name and email must be filled
    if (!newCustomer.full_name || !newCustomer.email) {
      alert("Please fill in Name and Email");
      return;
    }

    // Create a new customer object with a unique id
    const nextId = list.length + 1;
    const customerToAdd = {
      customer_id: nextId,
      ...newCustomer,
      joined_date: new Date().toISOString().split("T")[0], // today's date
      loyalty_points: 0,
    };

    // Add to our list (in real app, this would be saved to the database)
    setList([...list, customerToAdd]);

    // Reset the form and close the modal
    setNewCustomer({ full_name: "", email: "", phone: "", address: "" });
    setShowModal(false);
  }

  return (
    <div>
      <div className="page-header">
        <h1>Customers</h1>
        <p>All registered KIA car owners and their account details</p>
      </div>

      {/* Search bar and Add button side by side */}
      <div className="card">
        <div className="card-header">
          <input
            type="text"
            className="search-bar"
            placeholder="Search by customer name..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          />
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            + Add Customer
          </button>
        </div>

        {/* Customer Table */}
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Joined</th>
                <th>Loyalty Points</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                // Show message when no results found
                <tr>
                  <td colSpan="7">
                    <div className="empty-state">
                      <p>No customers found matching "{searchText}"</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map((c) => (
                  <tr key={c.customer_id}>
                    <td className="text-muted">{c.customer_id}</td>
                    <td className="text-bold">{c.full_name}</td>
                    <td>{c.email}</td>
                    <td>{c.phone}</td>
                    <td>{c.address}</td>
                    <td>{c.joined_date}</td>
                    <td>
                      <span className="badge badge-blue">⭐ {c.loyalty_points} pts</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ---- ADD CUSTOMER MODAL ---- */}
      {/* Only shown when showModal is true */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h2>Add New Customer</h2>

            <div className="form-row">
              <div className="form-group">
                <label>Full Name *</label>
                <input
                  type="text"
                  name="full_name"
                  value={newCustomer.full_name}
                  onChange={handleFormChange}
                  placeholder="e.g. Rohit Desai"
                />
              </div>
              <div className="form-group">
                <label>Email *</label>
                <input
                  type="email"
                  name="email"
                  value={newCustomer.email}
                  onChange={handleFormChange}
                  placeholder="e.g. rohit@email.com"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Phone Number</label>
                <input
                  type="text"
                  name="phone"
                  value={newCustomer.phone}
                  onChange={handleFormChange}
                  placeholder="10-digit mobile number"
                />
              </div>
              <div className="form-group">
                <label>Address</label>
                <input
                  type="text"
                  name="address"
                  value={newCustomer.address}
                  onChange={handleFormChange}
                  placeholder="City, State"
                />
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleAddCustomer}>
                Add Customer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Customers;
