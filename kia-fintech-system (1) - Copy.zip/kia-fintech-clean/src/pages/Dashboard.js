// ============================================================
// Dashboard.js  -  Home page with summary stats
// ============================================================
// This page shows:
//   1. Big stat numbers (total customers, revenue, etc.)
//   2. Recent payments table
//   3. Services status overview

import { customers, cars, services, payments, cashbacks } from "../data/mockData";

function Dashboard() {

  // --- Calculate summary numbers from our data ---

  // Total revenue = sum of all payments that are "Paid"
  const totalRevenue = payments
    .filter((p) => p.status === "Paid")
    .reduce((sum, p) => sum + p.amount, 0);

  // Pending payments = payments with status "Pending"
  const pendingCount = payments.filter((p) => p.status === "Pending").length;

  // Total cashback given
  const totalCashback = cashbacks.reduce((sum, c) => sum + c.cashback_amount, 0);

  // Active services (not completed)
  const activeServices = services.filter((s) => s.status !== "Completed").length;

  // Helper: get customer name by their id
  function getCustomerName(customerId) {
    const found = customers.find((c) => c.customer_id === customerId);
    return found ? found.full_name : "Unknown";
  }

  // Helper: give a CSS class name based on payment status
  function paymentBadge(status) {
    if (status === "Paid")    return "badge badge-green";
    if (status === "Pending") return "badge badge-orange";
    return "badge badge-grey";
  }

  // Helper: give a CSS class based on service status
  function serviceBadge(status) {
    if (status === "Completed")   return "badge badge-green";
    if (status === "In Progress") return "badge badge-blue";
    if (status === "Pending")     return "badge badge-orange";
    return "badge badge-grey";
  }

  return (
    <div>
      {/* Page title */}
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Welcome to KIA Garage FinTech — here is today's overview</p>
      </div>

      {/* ---- STAT CARDS ---- */}
      <div className="stats-grid">

        <div className="stat-card">
          <div className="stat-icon red">👥</div>
          <div className="stat-info">
            <h3>{customers.length}</h3>
            <p>Total Customers</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon green">💰</div>
          <div className="stat-info">
            <h3>₹{totalRevenue.toLocaleString()}</h3>
            <p>Total Revenue</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon blue">🚗</div>
          <div className="stat-info">
            <h3>{cars.length}</h3>
            <p>Cars Registered</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon orange">🔧</div>
          <div className="stat-info">
            <h3>{activeServices}</h3>
            <p>Active Services</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon red">🕐</div>
          <div className="stat-info">
            <h3>{pendingCount}</h3>
            <p>Pending Payments</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon green">🎁</div>
          <div className="stat-info">
            <h3>₹{totalCashback.toLocaleString()}</h3>
            <p>Total Cashback Given</p>
          </div>
        </div>

      </div>

      {/* ---- TWO COLUMN SECTION ---- */}
      <div className="two-col-grid">

        {/* Recent Payments */}
        <div className="card">
          <div className="card-header">
            <h3>Recent Payments</h3>
          </div>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Amount</th>
                  <th>Method</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((pay) => (
                  <tr key={pay.payment_id}>
                    <td className="text-bold">{getCustomerName(pay.customer_id)}</td>
                    <td>₹{pay.amount.toLocaleString()}</td>
                    <td>{pay.payment_method}</td>
                    <td>
                      <span className={paymentBadge(pay.status)}>{pay.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Service Status */}
        <div className="card">
          <div className="card-header">
            <h3>Services Overview</h3>
          </div>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Service</th>
                  <th>Mechanic</th>
                  <th>Cost</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {services.map((s) => (
                  <tr key={s.service_id}>
                    <td className="text-bold">{s.service_type}</td>
                    <td className="text-muted">{s.mechanic_name}</td>
                    <td>₹{s.cost.toLocaleString()}</td>
                    <td>
                      <span className={serviceBadge(s.status)}>{s.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}

export default Dashboard;
