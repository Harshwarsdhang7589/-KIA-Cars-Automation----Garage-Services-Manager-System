// ============================================================
// Payments.js  -  Payment records and invoices
// ============================================================
// Features:
//   - View all payments with customer name and invoice number
//   - Add a new payment record
//   - Mark pending payments as paid

import { useState } from "react";
import { payments as initialPayments, customers, services } from "../data/mockData";

function Payments() {
  const [list, setList] = useState(initialPayments);
  const [showModal, setShowModal] = useState(false);

  const paymentMethods = ["Cash", "Card", "UPI", "Loan", "Bank Transfer"];

  const [newPayment, setNewPayment] = useState({
    customer_id: "",
    service_id: "",
    amount: "",
    payment_method: "UPI",
    status: "Paid",
  });

  function handleChange(e) {
    setNewPayment({ ...newPayment, [e.target.name]: e.target.value });
  }

  // Generate a new invoice number like INV-2024-005
  function generateInvoice(currentList) {
    const num = String(currentList.length + 1).padStart(3, "0");
    return `INV-2024-${num}`;
  }

  function handleAdd() {
    if (!newPayment.customer_id || !newPayment.amount) {
      alert("Please fill Customer and Amount");
      return;
    }

    const toAdd = {
      payment_id: list.length + 1,
      ...newPayment,
      customer_id: parseInt(newPayment.customer_id),
      service_id:  newPayment.service_id ? parseInt(newPayment.service_id) : null,
      amount:      parseFloat(newPayment.amount),
      payment_date: new Date().toISOString().split("T")[0],
      invoice_number: generateInvoice(list),
    };

    setList([...list, toAdd]);
    setNewPayment({ customer_id: "", service_id: "", amount: "", payment_method: "UPI", status: "Paid" });
    setShowModal(false);
  }

  // Toggle a payment status between Paid and Pending
  function toggleStatus(paymentId) {
    setList(list.map((p) => {
      if (p.payment_id === paymentId) {
        return { ...p, status: p.status === "Paid" ? "Pending" : "Paid" };
      }
      return p;
    }));
  }

  function getCustomerName(id) {
    const c = customers.find((c) => c.customer_id === id);
    return c ? c.full_name : "Unknown";
  }

  function getServiceLabel(id) {
    if (!id) return "Car Purchase";
    const s = services.find((s) => s.service_id === id);
    return s ? s.service_type : "N/A";
  }

  function getPaymentBadge(status) {
    if (status === "Paid")     return "badge badge-green";
    if (status === "Pending")  return "badge badge-orange";
    if (status === "Refunded") return "badge badge-red";
    return "badge badge-grey";
  }

  // Total of all paid payments
  const totalPaid = list
    .filter((p) => p.status === "Paid")
    .reduce((sum, p) => sum + p.amount, 0);

  return (
    <div>
      <div className="page-header">
        <h1>Payments</h1>
        <p>Track all customer payments, invoices and outstanding dues</p>
      </div>

      {/* Summary bar */}
      <div className="stats-grid" style={{ marginBottom: "20px" }}>
        <div className="stat-card">
          <div className="stat-icon green">✅</div>
          <div className="stat-info">
            <h3>₹{totalPaid.toLocaleString()}</h3>
            <p>Total Collected</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">⏳</div>
          <div className="stat-info">
            <h3>{list.filter((p) => p.status === "Pending").length}</h3>
            <p>Pending Payments</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">🧾</div>
          <div className="stat-info">
            <h3>{list.length}</h3>
            <p>Total Invoices</p>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3>All Payment Records</h3>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            + Record Payment
          </button>
        </div>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Customer</th>
                <th>Service</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {list.map((pay) => (
                <tr key={pay.payment_id}>
                  <td style={{ fontFamily: "monospace", fontSize: "12px" }}>
                    {pay.invoice_number}
                  </td>
                  <td className="text-bold">{getCustomerName(pay.customer_id)}</td>
                  <td>{getServiceLabel(pay.service_id)}</td>
                  <td className="text-bold">₹{pay.amount.toLocaleString()}</td>
                  <td>{pay.payment_method}</td>
                  <td>{pay.payment_date}</td>
                  <td>
                    <span className={getPaymentBadge(pay.status)}>{pay.status}</span>
                  </td>
                  <td>
                    {/* Only show toggle button for Paid/Pending, not Refunded */}
                    {pay.status !== "Refunded" && (
                      <button
                        className="btn btn-outline"
                        style={{ padding: "4px 10px", fontSize: "12px" }}
                        onClick={() => toggleStatus(pay.payment_id)}
                      >
                        {pay.status === "Paid" ? "Mark Pending" : "Mark Paid"}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD PAYMENT MODAL */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h2>Record New Payment</h2>

            <div className="form-row">
              <div className="form-group">
                <label>Customer *</label>
                <select name="customer_id" value={newPayment.customer_id} onChange={handleChange}>
                  <option value="">-- Select Customer --</option>
                  {customers.map((c) => (
                    <option key={c.customer_id} value={c.customer_id}>{c.full_name}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>Linked Service (optional)</label>
                <select name="service_id" value={newPayment.service_id} onChange={handleChange}>
                  <option value="">-- None (Car Purchase) --</option>
                  {services.map((s) => (
                    <option key={s.service_id} value={s.service_id}>{s.service_type}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Amount (₹) *</label>
                <input
                  type="number"
                  name="amount"
                  value={newPayment.amount}
                  onChange={handleChange}
                  placeholder="e.g. 2500"
                />
              </div>
              <div className="form-group">
                <label>Payment Method</label>
                <select name="payment_method" value={newPayment.payment_method} onChange={handleChange}>
                  {paymentMethods.map((m) => <option key={m}>{m}</option>)}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Status</label>
              <select name="status" value={newPayment.status} onChange={handleChange}>
                <option>Paid</option>
                <option>Pending</option>
              </select>
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleAdd}>Save Payment</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Payments;
