// ============================================================
// Services.js  -  Garage service jobs
// ============================================================
// Features:
//   - View all service records with status
//   - Filter by status (Pending / In Progress / Completed)
//   - Add new service job

import { useState } from "react";
import { services as initialServices, cars, customers } from "../data/mockData";

function Services() {
  const [list, setList] = useState(initialServices);
  const [statusFilter, setStatusFilter] = useState("All"); // filter dropdown
  const [showModal, setShowModal] = useState(false);

  const serviceTypes = [
    "Oil Change",
    "AC Service",
    "Wheel Alignment",
    "Brake Service",
    "Annual Service",
    "Battery Check",
    "Tyre Replacement",
    "Engine Checkup",
    "Software Update",
  ];

  const [newService, setNewService] = useState({
    car_id: "",
    service_type: "",
    description: "",
    service_date: "",
    cost: "",
    status: "Pending",
    mechanic_name: "",
  });

  function handleChange(e) {
    setNewService({ ...newService, [e.target.name]: e.target.value });
  }

  function handleAdd() {
    if (!newService.car_id || !newService.service_type || !newService.cost) {
      alert("Please fill Car, Service Type and Cost");
      return;
    }

    const toAdd = {
      service_id: list.length + 1,
      ...newService,
      car_id: parseInt(newService.car_id),
      cost: parseFloat(newService.cost),
    };

    setList([...list, toAdd]);
    setNewService({
      car_id: "", service_type: "", description: "",
      service_date: "", cost: "", status: "Pending", mechanic_name: "",
    });
    setShowModal(false);
  }

  // Get car details and owner name from car_id
  function getCarInfo(carId) {
    const car = cars.find((c) => c.car_id === carId);
    if (!car) return { label: "Unknown", owner: "Unknown" };
    const owner = customers.find((c) => c.customer_id === car.customer_id);
    return {
      label: `${car.model} (${car.reg_number})`,
      owner: owner ? owner.full_name : "Unknown",
    };
  }

  // Filter list based on selected status
  const filtered = statusFilter === "All"
    ? list
    : list.filter((s) => s.status === statusFilter);

  function getStatusBadge(status) {
    if (status === "Completed")   return "badge badge-green";
    if (status === "In Progress") return "badge badge-blue";
    return "badge badge-orange";
  }

  return (
    <div>
      <div className="page-header">
        <h1>Services</h1>
        <p>All garage service jobs — track progress and assign mechanics</p>
      </div>

      {/* Quick filter buttons */}
      <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
        {["All", "Pending", "In Progress", "Completed"].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`btn ${statusFilter === s ? "btn-primary" : "btn-outline"}`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="card">
        <div className="card-header">
          <h3>Service Records ({filtered.length})</h3>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            + New Service Job
          </button>
        </div>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Car / Owner</th>
                <th>Service Type</th>
                <th>Description</th>
                <th>Date</th>
                <th>Cost</th>
                <th>Mechanic</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => {
                const info = getCarInfo(s.car_id);
                return (
                  <tr key={s.service_id}>
                    <td className="text-muted">{s.service_id}</td>
                    <td>
                      <div className="text-bold">{info.owner}</div>
                      <div className="text-muted">{info.label}</div>
                    </td>
                    <td className="text-bold">{s.service_type}</td>
                    <td className="text-muted">{s.description}</td>
                    <td>{s.service_date}</td>
                    <td>₹{s.cost.toLocaleString()}</td>
                    <td>{s.mechanic_name}</td>
                    <td>
                      <span className={getStatusBadge(s.status)}>{s.status}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD SERVICE MODAL */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h2>New Service Job</h2>

            <div className="form-row">
              <div className="form-group">
                <label>Select Car *</label>
                <select name="car_id" value={newService.car_id} onChange={handleChange}>
                  <option value="">-- Select Car --</option>
                  {cars.map((car) => (
                    <option key={car.car_id} value={car.car_id}>
                      {car.model} – {car.reg_number}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>Service Type *</label>
                <select name="service_type" value={newService.service_type} onChange={handleChange}>
                  <option value="">-- Select Type --</option>
                  {serviceTypes.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Description</label>
              <input
                type="text"
                name="description"
                value={newService.description}
                onChange={handleChange}
                placeholder="Briefly describe the work"
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Service Date</label>
                <input type="date" name="service_date" value={newService.service_date} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label>Cost (₹) *</label>
                <input
                  type="number"
                  name="cost"
                  value={newService.cost}
                  onChange={handleChange}
                  placeholder="e.g. 1500"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Mechanic Name</label>
                <input
                  type="text"
                  name="mechanic_name"
                  value={newService.mechanic_name}
                  onChange={handleChange}
                  placeholder="e.g. Manoj Kumar"
                />
              </div>
              <div className="form-group">
                <label>Status</label>
                <select name="status" value={newService.status} onChange={handleChange}>
                  <option>Pending</option>
                  <option>In Progress</option>
                  <option>Completed</option>
                </select>
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleAdd}>Add Service</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Services;
